import 'dart:async';
import 'package:batliwala/RegisterScreen.dart';
import 'package:flutter/material.dart';

class FirstSplash extends StatefulWidget {
  const FirstSplash({Key? key}) : super(key: key);

  @override
  State<FirstSplash> createState() => _FirstSplashState();
}

class _FirstSplashState extends State<FirstSplash> {
  @override
  void initState() {
    super.initState();
    Timer(
        Duration(seconds: 5),
        () => Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (context) => RegisterScreen())));
  }

  // @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: Container(
                height: MediaQuery.of(context).size.height * 0.2,
                width: MediaQuery.of(context).size.width * 0.5,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(
                          'assets/Splash.gif',
                        ),
                        fit: BoxFit.fill)),
                padding: EdgeInsets.all(4.0),
                child: Center(
                  child: CircularProgressIndicator(color: Color(0xFF4D9995),),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
